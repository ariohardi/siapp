<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function do_login()
	{
		$this->db->where(array(
			'email'=>$this->input->post('email',true),
			'password'=>$this->aang->superhash($_POST['password'])
			));
		$user = $this->db->get('admin')->row();
		if($user){
			$this->session->set_userdata((array) $user);
			return array(
				'status'=>true,
				'message'=>'Login berhasil, mohon tunggu sebentar.',
				'ID'=>$user->ID,
				'user'=>$user);
		} return array('status'=>false,'message'=>'Login gagal, alamat email atau password salah.');
	}

}
