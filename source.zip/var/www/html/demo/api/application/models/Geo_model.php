<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Geo_model extends CI_Model {

	public function propinsi()
	{
		$this->db->order_by('nama_propinsi');
		$data = $this->db->get('propinsi')->result();
		return $data;
	}

	public function kabupaten()
	{
		$this->db->where( $this->input->post(null,true) );
		$this->db->order_by('nama_kabupaten');
		$data = $this->db->get('kabupaten')->result();
		return $data;
	}

}
