<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Geo extends CI_Controller {

	public function propinsi()
	{
		$this->load->model('Geo_model');
		$data = $this->Geo_model->propinsi();
		exit(json_encode($data));
	}

	public function kabupaten()
	{
		$this->load->model('Geo_model');
		$data = $this->Geo_model->kabupaten();
		exit(json_encode($data));
	}

}
