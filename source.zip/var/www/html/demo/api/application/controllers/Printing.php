<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Printing extends CI_Controller {

	public function absensi_harian($tanggal)
	{
		$this->load->model('Absensi_model');
		$data['judul'] = "Absensi Harian ".date("d/m/Y",strtotime($tanggal));
		$data['data'] = $this->Absensi_model->data_absensi_harian($tanggal);
		$this->load->view('printing/absensi_harian',$data);
	}

	public function cv($md5_id)
	{
		$this->load->model('Personil_model');
		$data['personil'] = $this->Personil_model->detail($md5_id);
		$this->load->view('printing/cv',$data);	
	}

	public function data_personil()
	{
		if($this->input->get('export')==="excel"){
			header("Content-type: application/vnd-ms-excel");
			header("Content-Disposition: attachment; filename=data-personil-".date("d-m-Y").".xls");
		}
		$this->load->model('Personil_model');
		$data['judul'] = "Data Personil";
		$data['data'] = $this->Personil_model->dataprint();
		$this->load->view('printing/data_personil',$data);	
	}

}
