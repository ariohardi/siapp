<?php session_start(); if(isset($_POST['ID'])) $_SESSION['ID'] = $_POST['ID']; if(!isset($_SESSION['ID'])) header("Location: ./login"); ?>
<!doctype html>
<html lang="en" ng-app="RDash">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<title ng-bind="title_tag ? title_tag : page_title"></title>
  <!-- STYLES -->
	<meta name="robots" content="noindex,nofollow" />
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/highcharts-3d.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <link rel="stylesheet" href="lib/css/main.min.css"/>
  <link rel="stylesheet" href="js/popover/src/jquery.webui-popover.css"/>
  <link rel="stylesheet" href="js/magnific-popup/dist/magnific-popup.css"/>
  <link rel="stylesheet" href="lib/new/zebra-dialog/public/css/flat/zebra_dialog.css" type="text/css" />
  <script src="//cdn.sinch.com/latest/sinch.min.js"></script>
  <style>
  .ZebraDialog .ZebraDialog_Body {
  padding: 0px !important;
  }
  </style>
  <!-- SCRIPTS -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCHicCY8Oao_qeu4dIZbC5vGrx4IwOhOp4&libraries=places"></script>
  <script src="lib/js/main.min.js"></script>
  <script type="text/javascript" src="js/ng-file-upload-master/dist/ng-file-upload-shim.min.js"></script>
  <script type="text/javascript" src="js/ng-file-upload-master/dist/ng-file-upload.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
  <script src="js/angular-chart.min.js"></script>
  <script src="js/angular-base64-upload-master/dist/angular-base64-upload.min.js"></script>
  <script src="js/angular-cuppa-datepicker-master/js/lib/moment.js"></script>
  <script src="js/angular-cuppa-datepicker-master/js/datepicker-directive.js"></script>
  <!-- Custom Scripts -->
  <!-- <script type="text/javascript" src="ng-controller/dashboard.min.js"></script> -->
  <script type="text/javascript" src="script.php"></script>
  <script type="text/javascript" src="login/index_files/jquery.min.js"></script>
  <script type="text/javascript" src="js/ztree/js/jquery.ztree.all.min.js"></script>
  <script type="text/javascript" src="bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery.playSound.js"></script>
  <script type="text/javascript" src="js/angucomplete-master/angucomplete.js"></script>
  <script type="text/javascript" src="js/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
  <script type="text/javascript" src="js/jquery-toast-plugin-master/src/jquery.toast.js"></script>
  <script type="text/javascript" src="lib/new/zebra-dialog/public/javascript/zebra_dialog.js"></script>
  <script type="text/javascript" src="lib/new/angularLocationpicker.jquery.min.js"></script>
  <script type="text/javascript" src="lib/new/locationpicker.jquery.js"></script>
  <script src="https://www.gstatic.com/firebasejs/3.6.7/firebase.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/webui-popover/2.1.15/jquery.webui-popover.min.js"></script>
  <script>
    var config = {
      apiKey: "AIzaSyAUZxgMcZhe5eFiMU8Z5wnj-46NlaS4_Xg",
      authDomain: "rational-genius-106804.firebaseapp.com",
      databaseURL: "https://rational-genius-106804.firebaseio.com",
      storageBucket: "rational-genius-106804.appspot.com",
      messagingSenderId: "109014983012"
    };
    firebase.initializeApp(config);
  </script>
  <script type="text/javascript">
    function public_chatting(data){ 
      new jQuery.Zebra_Dialog('', {
          source: {'iframe': {
              'src':  '/web/custom/iframe_chatting.php?'+jQuery.param(data,true),
              'height': 500
          }},
          width: 800,
          title: 'Online Chatting',
          type: false
      });
    }
    jQuery(document).ready(function(){
      jQuery('#menu-item-91').css('cursor','pointer').click(function(){
        public_chatting();
      });
    });
  </script>
  <link rel="stylesheet" type="text/css" href="js/jquery-toast-plugin-master/src/jquery.toast.css" />
  <link rel="stylesheet" type="text/css" href="js/angular-cuppa-datepicker-master/css/cuppa-datepicker-styles.css" />
  <link rel="stylesheet" type="text/css" href="lib/font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="js/ztree/css/zTreeStyle/zTreeStyle.css">
  <link rel="stylesheet" type="text/css" href="js/angucomplete-master/angucomplete.css?a=<?php echo uniqid() ?>">
  <style type="text/css">
    #map {
        min-height: 400px;
    }
  </style>
</head>
<body ng-controller="MasterCtrl">
  <div id="page-wrapper" ng-class="{'open': toggle}" ng-cloak>

    <!-- Sidebar -->
    <div id="sidebar-wrapper">
      <ul class="sidebar">
        <li class="sidebar-main">
          <a ng-click="toggleSidebar()">
            SIAPP
            <span class="menu-icon glyphicon glyphicon-transfer"></span>
          </a>
        </li>
        <li class="sidebar-title"><span>Navigasi</span></li>
        <li class="sidebar-list">
          <a href="#">Overview <span class="menu-icon fa fa-tachometer"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/cabang">Kantor Cabang <span class="menu-icon fa fa-sitemap"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/klien">Data Klien <span class="menu-icon fa fa-address-book-o"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/proyek">Proyek <span class="menu-icon fa fa-flag"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/personil">Data Personil <span class="menu-icon fa fa-user"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/regu">Regu <span class="menu-icon fa fa-group"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/pesan">Instruksi <span class="menu-icon fa fa-warning"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/laporan_personil">Laporan Personil <span class="menu-icon fa fa-file"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/panic_signal">Sinyal Tombol Panik <span class="menu-icon fa fa-bullseye"></span></a>
        </li>
        <!-- <li class="sidebar-list">
          <a href="#/managemen_arsip">Managemen Arsip <span class="menu-icon fa fa-folder"></span></a>
        </li> -->
        <li class="sidebar-list">
          <a href="#/absensi">Data Absensi <span class="menu-icon fa fa-folder"></span></a>
        </li>
        <!-- <li class="sidebar-list">
          <a href="javascript:void(0)">Update Berita <span class="menu-icon fa fa-newspaper-o"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="javascript:void(0)">Website <span class="menu-icon fa fa-globe"></span></a>
        </li> -->
        <li class="sidebar-list">
          <a href="#/online_chatting">Online Chatting <span class="menu-icon fa fa-comments"></span></a>
        </li>
        <li class="sidebar-list">
          <a href="#/administrator">Daftar Admin <span class="menu-icon fa fa-address-card"></span></a>
        </li>
        <!-- <li class="sidebar-list" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <a href="#/absensi">Data Absensi Personil <span class="menu-icon fa fa-clock-o"></span></a>
        </li> -->
      </ul>
      <div class="sidebar-footer">
        <div class="col-xs-4">
          <a href="http://www.sigapp.net/web" target="_blank">
            Website
          </a>
        </div>
        <div class="col-xs-4">
          <a href="javascript:void(0)" target="_blank">
            Setting
          </a>
        </div>
        <div class="col-xs-4">
          <a href="login">
            Keluar
          </a>
        </div>
      </div>
    </div>
    <!-- End Sidebar -->
    
    <div id="content-wrapper">
      <div class="page-content">

        <!-- Header Bar -->
        <div class="row header">
          <div class="col-xs-12">
            <div class="user pull-right">
              <div class="item dropdown">
                <a href="#" class="dropdown-toggle">
                  <img style="height: 60px !important;width: auto !important;margin-top: 4px !important;" src="logoa.png?a=1">
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li class="dropdown-header">
                    Joe Bloggs
                  </li>
                  <li class="divider"></li>
                  <li class="link">
                    <a href="#">
                      Profile
                    </a>
                  </li>
                  <li class="link">
                    <a href="#">
                      Menu Item
                    </a>
                  </li>
                  <li class="link">
                    <a href="#">
                      Menu Item
                    </a>
                  </li>
                  <li class="divider"></li>
                  <li class="link">
                    <a href="#">
                      Logout
                    </a>
                  </li>
                </ul>
              </div>
              <div class="item dropdown">
               <a href="#" ng-click="clear_notifikasi_baru()" class="dropdown-toggle">
                  <span class="badge red" ng-bind="notifikasi_baru" ng-show="notifikasi_baru > 0"></span> <i class="fa fa-bell-o"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                  <li class="dropdown-header">
                    Pemberitahuan
                  </li>
                  <li class="divider"></li>
                  <li ng-repeat="notif in notifikasi_terakhir">
                    <a href="{{notif.link}}" ng-bind="notif.judul"></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="meta">
              <div class="page" id="main-title" ng-bind="page_title"></div>
              <div class="breadcrumb-links" ng-bind="breadcrumb_text"></div>
            </div>
          </div>
        </div>
        <!-- End Header Bar -->
        <!-- Main Content -->
        <div ui-view></div>
      </div><!-- End Page Content -->
    </div><!-- End Content Wrapper -->
  </div><!-- End Page Wrapper -->
</body>
</html>
